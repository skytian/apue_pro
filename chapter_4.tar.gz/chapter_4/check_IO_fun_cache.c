/*************************************************************************
    > File Name: check_IO_fun_cache.c
    > Author: wangtian
    > Mail: 317302030@qq.com 
    > Created Time: Wed 29 Jun 2016 09:45:42 AM CST
 ************************************************************************/

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<fcntl.h>

int main(int argv,char *argc[]) {
	int fd;
	if()
}
